import Cart from './Cart'
export default function Navbar(){
    return (
        <div className='flex justify-end pt-2 border-b border-gray-600 py-2'>
            <Cart/>
        </div>
    )
}


